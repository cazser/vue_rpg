<template>
    <h2>Hi, I am a vue component</h2>
</template>